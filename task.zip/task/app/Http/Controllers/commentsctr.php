<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\admin;
use App\Models\customer;
use App\Models\comments;
class commentsctr extends Controller
{
    //

    function usertype(Request $request){

        $data = $request->all();
        if(strtolower($data["usertype"])=="admin"){
            $data=admin::all();
        }else{
             $data=customer::all();
        }
        return $data;
    }


    function savecomments(Request $request){

        $request->validate([
          'usertype'      => 'required',
          'user'     => 'required',
          'description'    => 'required',
        ]);
        $data = $request->all();


        $user = comments::create(['user_type' => $data["usertype"],"user_list"=>$data["user"],"description"=>$data["description"],"created_at"=>date('Y-m-d H:i:s')]);

        return $data["description"];
    }


    function allcomments(){


         $customer = comments::select('comments.id', 'comments.user_type','comments.user_list','comments.description','comments.created_at' ,'customer.name'  )
        ->join('customer', 'comments.user_list', '=', 'customer.id')
        ->where('user_type', '=', 'customer')
        ->get()
        ->toArray();

        $admin = comments::select('comments.id', 'comments.user_type','comments.user_list','comments.description','comments.created_at','admin.name'  )
            ->join('admin', 'comments.user_list', '=', 'admin.id')
        ->where('user_type', '=', 'admin')
        ->get()
        ->toArray();

    $comments = collect(array_merge($customer, $admin))->sortBy('id')->toArray();


        return $comments;
    }
}
