<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\admin;
class adminctr extends Controller
{
    //
     function show(){
        $asd=admin::all();
        return $asd;
    }
}
