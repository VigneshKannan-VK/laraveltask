<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\customer;
class customerctr extends Controller
{
    //
    function show(){
        $asd=customer::all();
        return $asd;
    }
}
