<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\adminctr;
use App\Http\Controllers\customerctr;
use App\Http\Controllers\commentsctr;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// Route::get('/admin', function () {
//     return view('welcome');
// });


Route::POST('/getuser', [commentsctr::class, 'usertype']);
Route::POST('/admin', [adminctr::class, 'show']);
Route::POST('/customer', [customerctr::class, 'show']);

Route::get('/allcomments', [commentsctr::class, 'allcomments']);

Route::POST('/savecomments', [commentsctr::class, 'savecomments']);
