<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
              <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<style>
  .left_{
    /*float: left;*/
    font-weight: 700;
  }

  .right_{
    float: right;
    /*font-weight: 700;*/
  }
</style>
</head>
<body>

<div class="container">
  <h2>Add Comment</h2>
  <form>
  <div class="form-group row">
    <label for="staticEmail" class="col-sm-2 col-form-label">User-Type</label>
    <div class="col-sm-10">
      <select class="form-control" id="user-type" onchange="usertype()">
        <option value="admin">Admin</option>
        <option value="customer">Customer</option>
      </select>
    </div>
  </div>
  <div class="form-group row">
    <label for="inputPassword" class="col-sm-2 col-form-label">User</label>
    <div class="col-sm-10">
      <select class="form-control" id="user">
        
      </select>
    </div>
  </div>
  <div class="form-group row">
    <label for="inputPassword" class="col-sm-2 col-form-label">Description</label>
    <div class="col-sm-10">
      <textarea name="description" id="description" cols="100" rows="4"></textarea>
    </div>
  </div>

  <button type="button" class="btn btn-success" onclick="savecomments()" id="btn-submit">Submit</button>
</form>
</div>

<div class="container">
  <h2> Comment</h2>
  <table class="table">
 
 <tbody id="bodyData">
   
  </tbody>
</table>
</div>

</body>
</html>



<script>


      usertype();
      allcomments();  



    function usertype(){
      $.ajax({
            url: "/getuser",
            type: "POST",
            data:{ 
                _token:'{{ csrf_token() }}',
                "usertype":$("#user-type").val(),
            },
            cache: false,
            dataType: 'json',
            success: function(dataResult){
                console.log(dataResult);
                var resultData = dataResult;
                var bodyData = '';
                var i=1;
                $.each(resultData,function(index,row){
                    bodyData+="<option value="+row.id+">"+row.name+"</option>";
                 })
                $("#user").html(bodyData);
            }
        });
    }


     function allcomments(){
      $.ajax({
            url: "allcomments",
            type: "GET",
            data:{ 
                _token:'{{ csrf_token() }}',
            },
            cache: false,
            dataType: 'json',
            success: function(dataResult){
                console.log(dataResult);
                var resultData = dataResult;
                var bodyData = '';
                var i=1;
                $.each(resultData,function(index,row){
                   bodyData+="<tr><td> <div> <span class='left_'>"+row.name+" - "+row.user_type+"</span> <span class='right_'>"+row.created_at+"</span> </div> <p class='desc'>"+row.description+"</p> </td></tr>";
                 })
                $("#bodyData").html(bodyData);
            }
        });
    }

     function savecomments(){


      var usertype=$("#user-type").val();
      var user=$("#user").val();
      var description=$("#description").val();

      if(user==""){
        alert("Select User");
        return false;
      } 

      if(description==""){
        alert("Enter description");
        return false;
      } 


      $.ajax({
            url: "savecomments",
            type: "POST",
            data:{ 
                _token:'{{ csrf_token() }}',
                usertype:usertype,
                user:user,
                description:description,
            },
            // cache: false,
            // dataType: 'json',
            success: function(dataResult){
                // console.log(dataResult);
                $("#description").val("");
                allcomments();
            }
        });
    }

</script>